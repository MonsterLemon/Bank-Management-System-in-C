# C Algorithms Project

This project contains implementations of algorithms in C.

## Files
- `src/algo_ff.c` : Main C source file.

## Build & Run
```bash
gcc src/algo_ff.c -o algo_ff
./algo_ff
```
