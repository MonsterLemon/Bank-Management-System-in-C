// auth.c - implementation file
