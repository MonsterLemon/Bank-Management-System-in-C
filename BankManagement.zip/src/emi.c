// emi.c - implementation file
