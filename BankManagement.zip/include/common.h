// common.h - header file
