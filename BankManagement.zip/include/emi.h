// emi.h - header file
