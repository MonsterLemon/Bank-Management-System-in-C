// auth.h - header file
