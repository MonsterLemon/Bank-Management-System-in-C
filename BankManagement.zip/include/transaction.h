// transaction.h - header file
